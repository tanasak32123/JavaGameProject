package entity;

public enum PlayType {
	fire , glob , water ;
}
