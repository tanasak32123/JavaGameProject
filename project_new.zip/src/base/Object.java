package base;

public abstract class Object {
	
	protected boolean isDead ;
	
	

}
