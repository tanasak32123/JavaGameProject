package Potion;

import entity.Maincharacter;

public interface Usable {
	
	void useItem(Maincharacter selectededCharacter);

}
