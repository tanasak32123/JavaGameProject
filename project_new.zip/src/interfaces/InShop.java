package interfaces;

public interface InShop {
	
	void isSoldOut();
	
}
