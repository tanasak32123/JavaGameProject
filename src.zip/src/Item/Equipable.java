package Item;


import entity.Player;

public interface Equipable {
	
	void equipItem(Player selectedCharacter);

	
}
