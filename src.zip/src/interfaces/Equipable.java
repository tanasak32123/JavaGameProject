package interfaces;

import Item.Equipment;

public interface Equipable {
	
	void equipItem(Equipment equipment);
	
}
