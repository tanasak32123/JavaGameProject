package interfaces;

import Potion.Potion;

public interface Usable {
	
	void useItem(Potion potion);

}
