package interfaces;

public interface IsAlive {
	
	

}
